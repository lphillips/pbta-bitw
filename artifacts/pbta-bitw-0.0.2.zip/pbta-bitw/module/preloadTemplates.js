export async function preloadTemplates() {
  const templatePaths = [
    // Add paths to "modules/pbta-bitw/templates"
  ];

  return loadTemplates(templatePaths);
}
