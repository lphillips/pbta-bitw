export function registerSettings() {
  // Register any custom module settings here
}
